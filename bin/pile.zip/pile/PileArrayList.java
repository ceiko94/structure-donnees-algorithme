package pile;
import java.util.*;

public class PileArrayList<T> implements Pile<T> {

	private int top=-1;
	private ArrayList<T> tabPile;
	
	public PileArrayList() 
	{
		tabPile = new ArrayList<T>();
	}
	
	public boolean vide()
	{
		return top == -1;
	}
	
	public void empiler(T o)
	{
		tabPile.add(o);
		top++;
	}
	
	public void depiler()
	{
		tabPile.remove(top);
		top--;
	}
	
	public T sommet()
	{
		return tabPile.get(top);
	}


}
