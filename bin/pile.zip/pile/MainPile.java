package pile;

public class MainPile {

	
	public static void main(String[] args)
	{
		PileArrayList<String> pl = new PileArrayList<String>();
		pl.empiler("debut");
		pl.empiler("cheikna");
		pl.empiler("dansoko");
		pl.empiler("fin");
		
		while(!pl.vide())
		{
			System.out.println(pl.sommet());
			pl.depiler();
		}
	}
		
	

}
