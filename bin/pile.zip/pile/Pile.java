package pile;

public interface Pile<T> 
{
	boolean vide();
	void empiler(T o);
	void depiler();

}
